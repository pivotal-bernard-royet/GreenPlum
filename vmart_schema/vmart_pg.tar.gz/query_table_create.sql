create table VmartQueryInput 
(
  query_text varchar(65000)
);

select implement_temp_design('VmartQueryInput');