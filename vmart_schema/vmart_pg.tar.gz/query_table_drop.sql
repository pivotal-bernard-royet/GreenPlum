drop table VmartQueryInput cascade;
