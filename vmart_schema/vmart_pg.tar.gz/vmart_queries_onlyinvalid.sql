insert into VmartQueryInput values (E'\n');
insert into VmartQueryInput values (NULL);
insert into VmartQueryInput values (E'\r');
