gpload -d vmart -f online_sales.Call_Center_Dimension.gpload.yml
gpload -d vmart -f Customer_Dimension.gpload.yml